# Fair AI App Deployment

Includes:
- simple_app.py
- requirements.txt
- models/
- baseline_model.pkl
- scaler.pkl

Deploy on Streamlit Cloud.
